#!/bin/sh
awk -f ../scan_tcga_miRNAs.awk tcga_dir="miRNA_testdata/" barcode_list="test_barcodes.txt" log2=1 test_miRNAs.txt
exit
