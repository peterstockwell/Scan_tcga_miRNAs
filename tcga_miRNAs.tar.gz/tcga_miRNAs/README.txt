		       TCGA miRNA data scanning

This directory contains the following:

scan_tcga_miRNAs.awk	 - script to perform scans
scan_tcga_miRNAs_doc.pdf - documentation
testdata_miRNA           - directory of test data
README.txt               - this file

Extensive documentation of the script requirements, options and usage
are in the pdf file.

In order to try the test data execute the following from this
directory:

cd testdata_miRNAs
./run_miRNA_test.sh

The output should be written to the terminal.

